/**
 * 
 */
/**
 * @author cimi
 *
 */
module SimpleActionEvent {
	requires java.desktop;
}