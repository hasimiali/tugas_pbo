/**
 * 
 */
/**
 * @author cimi
 *
 */
module SimpleMouseEvent {
	requires java.desktop;
}