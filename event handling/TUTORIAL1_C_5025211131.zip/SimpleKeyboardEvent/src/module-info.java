/**
 * 
 */
/**
 * @author cimi
 *
 */
module SimpleKeyboardEvent {
	requires java.desktop;
}