/**
 * 
 */
/**
 * @author cimi
 *
 */
module BouncingBallSimple {
	requires java.desktop;
}