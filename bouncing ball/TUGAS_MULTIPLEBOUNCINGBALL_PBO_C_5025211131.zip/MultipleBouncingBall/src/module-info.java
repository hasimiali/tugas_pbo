/**
 * 
 */
/**
 * @author cimi
 *
 */
module MultipleBouncingBall {
	requires java.desktop;
}