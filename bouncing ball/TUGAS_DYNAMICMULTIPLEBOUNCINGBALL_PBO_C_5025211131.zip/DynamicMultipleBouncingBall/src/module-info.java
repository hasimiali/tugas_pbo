/**
 * 
 */
/**
 * @author cimi
 *
 */
module DynamicMultipleBouncingBall {
	requires java.desktop;
}